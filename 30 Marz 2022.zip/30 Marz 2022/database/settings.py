# Parametros configuracion Servidor
conexion = {'host' : 'localhost', 
            'user' : 'root', 
            'passw': '',
            'database': 'adsi',
            'port': '',
            'tipo_bd': 'mysql', 
            }