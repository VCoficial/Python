from models.modelo import verUsuarios

def controladorUsuarios(name):
    return verUsuarios(name)